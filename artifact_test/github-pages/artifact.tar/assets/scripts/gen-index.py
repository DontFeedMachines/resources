import os
import subprocess
import math

def get_git_mtime(filepath):
    try:
        result = subprocess.run(
            ['git', 'log', '-1', '--format=%cd', '--date=format:%Y-%m-%d %H:%M', '--', filepath],
            capture_output=True, text=True, check=True
        )
        date_str = result.stdout.strip()
        return date_str if date_str else "Unknown"
    except Exception:
        return "Unknown"

def format_size(size_in_bytes):
    if size_in_bytes == 0:
        return "0B"
    size_name = ("B", "K", "M", "G", "T")
    i = int(math.floor(math.log(size_in_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_in_bytes / p, 1)
    s_str = str(s).replace(".0", "")
    return f"{s_str}{size_name[i]}"

HTML_HEADER = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>P480 {page_title} // DFM</title>
    <meta name="description" content="DFM resources archive." />
    <meta name="robots" content="noai, noimageai" />
    <meta name="tdm-reservation" content="1" />
    <link rel="stylesheet" href="/assets/dfm/dfm-static.css" />
    <style>
      .ls { width: 100%; border-collapse: collapse; font-size: 0.7em; }
      .ls th { color: var(--tt-magenta); font-weight: 400; text-align: left; border-bottom: 2px solid var(--tt-green); }
      .ls th, .ls td { padding: 0.15em 0.8em 0.15em 0; }
      .ls tr:last-child td { border-bottom: 2px solid var(--tt-green); padding-bottom: 0.4em; }
      .ls a { color: var(--tt-cyan); text-decoration: none; }
      .ls a:hover, .ls a:focus-visible { background: var(--tt-cyan); color: var(--tt-black); }
      .ls .right { text-align: right; }
      .ls-wrap { overflow-x: auto; }
      address { color: var(--tt-green); font-style: normal; font-size: 0.6em; margin-top: 1em; }
      
      /* Viewer Styles */
      .tt-content { font-family: 'Spline Sans Mono', 'Courier New', monospace; color: var(--tt-white); padding: 1em 0; font-size: 0.8em; line-height: 1.4; }
      .tt-content-raw { white-space: pre-wrap; }
      .tt-content-md h1, .tt-content-md h2, .tt-content-md h3 { color: var(--tt-magenta); font-weight: normal; margin-top: 1.5em; }
      .tt-content-md h1 { border-bottom: 1px solid var(--tt-magenta); padding-bottom: 0.2em; }
      .tt-content-md a { color: var(--tt-cyan); text-decoration: none; border-bottom: 1px dashed var(--tt-cyan); }
      .tt-content-md p { margin-bottom: 1em; }
      .tt-content-md code { background: rgba(255,255,255,0.1); padding: 0.1em 0.3em; color: var(--tt-yellow); }
      .tt-content-md pre { background: rgba(0,0,0,0.5); padding: 1em; overflow-x: auto; border: 1px solid var(--tt-green); }
      .tt-content-md pre code { background: none; color: var(--tt-green); }
      
      .viewer-nav { margin: 1em 0; border-top: 1px solid var(--tt-green); padding-top: 1em; display: flex; justify-content: space-between; }
      .viewer-nav a { color: var(--tt-cyan); text-decoration: none; }
      .viewer-nav a:hover { background: var(--tt-cyan); color: var(--tt-black); }
    </style>
    <script>
      (function () {
        var d = document.documentElement;
        try {
          if (localStorage.getItem("dfm:plain") === "1") d.setAttribute("data-plain", "");
          if (localStorage.getItem("dfm:scan") === "0") d.setAttribute("data-noscan", "");
        } catch (e) {}
      })();
    </script>
  </head>
  <body>
    <a class="skip-link" href="#main">skip to content</a>
    <dfm-sector-bar current="dfm"></dfm-sector-bar>
    <div class="bezel">
      <div class="screen" data-page="480" data-subpages="0">
        <div class="scanline" aria-hidden="true"></div>
        <header class="tt-head">
          <span class="tt-pnum" data-pnum aria-live="polite">P480</span>
          <span class="tt-title">RSRC_DB</span>
          <label class="tt-jump">JUMP TO: <input type="text" inputmode="numeric" maxlength="3" placeholder="---" aria-label="page number" data-jump autocomplete="off" /></label>
          <span class="tt-clock" data-clock>--:--:--</span>
        </header>
        <div class="tt-flags" aria-live="polite">
          <span data-flag-hold hidden>HOLD</span>
          <span data-flag-sub hidden></span>
          <span data-flag-reveal hidden class="magenta">REVEAL</span>
        </div>
        <nav class="tt-nav" aria-label="pages">
          <a href="/" aria-current="page"><span class="n">480</span>files</a>
          <a href="/toolkit/"><span class="n">481</span>toolkit</a>
          <a href="/guides/"><span class="n">482</span>guides</a>
          <a href="/legal/"><span class="n">483</span>legal</a>
          <a href="/docs-hold/"><span class="n">484</span>docs</a>
          <a href="https://dontfeedmachines.com/"><span class="n">100</span>dfm</a>
          <a href="https://legal.dontfeedmachines.com/"><span class="n">710</span>legal-db</a>
        </nav>
        <main id="main" class="tt-body">"""

HTML_FOOTER = """        </main>
        <nav class="tt-fast" aria-label="fastext">
          <a href="/" class="f-red" data-fast="r">INDEX<span class="k" aria-hidden="true">R</span></a>
          <a href="/toolkit/" class="f-green" data-fast="g">TOOLKIT<span class="k" aria-hidden="true">G</span></a>
          <a href="/guides/" class="f-yellow" data-fast="y">GUIDES<span class="k" aria-hidden="true">Y</span></a>
          <a href="/legal/" class="f-cyan" data-fast="b">LEGAL<span class="k" aria-hidden="true">B</span></a>
        </nav>
      </div>
    </div>
    <p class="tt-foot">type any page number // R G Y B for the colored keys // L reveal // H hold // P for subtitles // / search</p>
    <dfm-palette src="#tt-search" placeholder="search pages by number or name"></dfm-palette>
    <dfm-keys lens="REVEAL: show the decoy text crawlers get" plain="SUBTITLES: plain mode"></dfm-keys>
    <script type="application/json" id="tt-map">{"480":"/","481":"/toolkit/","482":"/guides/","483":"/legal/","484":"/docs-hold/","100":"https://dontfeedmachines.com/","200":"https://dontfeedmachines.com/manifesto","300":"https://dontfeedmachines.com/words","400":"https://dontfeedmachines.com/kit","500":"https://dontfeedmachines.com/sectors","600":"https://dontfeedmachines.com/posture","700":"https://dontfeedmachines.com/license","800":"https://dontfeedmachines.com/crawlers","888":"https://dontfeedmachines.com/888","999":"https://dontfeedmachines.com/all","710":"https://legal.dontfeedmachines.com/"}</script>
    <script type="application/json" id="tt-search">[{"title":"P480 rsrc files","href":"/","kind":"page"},{"title":"P481 toolkit","href":"/toolkit/","kind":"page"},{"title":"P482 guides","href":"/guides/","kind":"page"},{"title":"P483 legal","href":"/legal/","kind":"page"},{"title":"P484 docs-hold","href":"/docs-hold/","kind":"page"},{"title":"P100 DFM index","href":"https://dontfeedmachines.com/","kind":"sector"},{"title":"P710 legal-db","href":"https://legal.dontfeedmachines.com/","kind":"sector"}]</script>
    <script type="module" src="/assets/dfm/teletext.js"></script>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        const params = new URLSearchParams(window.location.search);
        const viewFile = params.get('view');
        if (viewFile) {
          document.getElementById('dir-view').style.display = 'none';
          document.getElementById('file-view').style.display = 'block';
          document.title = "P480 VIEW " + viewFile + " // DFM";
          document.getElementById('fv-title').textContent = "FILE: " + viewFile;
          document.getElementById('fv-raw').href = viewFile;
          
          fetch(viewFile)
            .then(r => {
              if (!r.ok) throw new Error("File not found");
              return r.text();
            })
            .then(text => {
              const fvContent = document.getElementById('fv-content');
              if (viewFile.toLowerCase().endsWith('.md')) {
                const script = document.createElement('script');
                script.src = "https://cdn.jsdelivr.net/npm/marked/marked.min.js";
                script.onload = () => {
                  fvContent.innerHTML = '<div class="tt-content-md">' + marked.parse(text) + '</div>';
                };
                document.head.appendChild(script);
              } else {
                fvContent.textContent = text;
                fvContent.className = "tt-content tt-content-raw";
              }
            })
            .catch(err => {
              document.getElementById('fv-content').textContent = "Error loading file: " + err;
            });
        }
      });
    </script>
  </body>
</html>"""

def generate_index_for_directory(dir_path, root_dir):
    rel_path = os.path.relpath(dir_path, root_dir)
    if rel_path == '.':
        display_path = "/RSRC"
    else:
        display_path = f"/RSRC/{rel_path}"

    entries = os.listdir(dir_path)
    entries.sort()
    
    ignored = {'.git', '.github', 'assets', 'index.html', 'CNAME', '.DS_Store', '.nojekyll'}
    
    dirs = [e for e in entries if os.path.isdir(os.path.join(dir_path, e)) and e not in ignored and not e.startswith('.')]
    
    files = []
    for e in entries:
        if os.path.isfile(os.path.join(dir_path, e)) and e not in ignored and not e.startswith('.'):
            files.append(e)
            
    rows = []
    
    for d in dirs:
        full_d = os.path.join(dir_path, d)
        mtime = get_git_mtime(full_d)
        rows.append(f'              <tr><td><a href="{d}/">{d}/</a></td><td>{mtime}</td><td class="right">  - </td><td>&nbsp;</td></tr>')
        
    for f in files:
        full_f = os.path.join(dir_path, f)
        mtime = get_git_mtime(full_f)
        size = format_size(os.path.getsize(full_f))
        
        ext = os.path.splitext(f)[1].lower()
        is_text = ext in {'.md', '.txt', '.csv', '.json', '.yml', '.yaml', '.xml', ''}
        
        if is_text:
            rows.append(f'              <tr><td><a href="?view={f}">{f}</a></td><td>{mtime}</td><td class="right">{size}</td><td>&nbsp;</td></tr>')
        else:
            rows.append(f'              <tr><td><a href="{f}">{f}</a></td><td>{mtime}</td><td class="right">{size}</td><td>&nbsp;</td></tr>')

    parent_link = '              <tr><td><a href="../">Parent Directory</a></td><td>&nbsp;</td><td class="right">  - </td><td>&nbsp;</td></tr>\n'
    if rel_path == '.':
        parent_link = ''

    index_html = HTML_HEADER.replace("{page_title}", f"INDEX OF {display_path}")
    
    index_html += f'\n          <div id="dir-view">'
    index_html += f'\n            <span class="dh yellow">INDEX OF {display_path}</span>'
    index_html += '\n            <div class="ls-wrap">\n              <table class="ls">'
    index_html += '\n                <tr><th>Name</th><th>Last modified</th><th class="right">Size</th><th>Description</th></tr>\n'
    if parent_link:
        index_html += parent_link
    index_html += '\n'.join(rows)
    index_html += '\n              </table>\n            </div>'
    index_html += '\n          </div>'
    
    index_html += '\n          <div id="file-view" style="display: none;">'
    index_html += '\n            <span class="dh yellow" id="fv-title"></span>'
    index_html += '\n            <div class="tt-content" id="fv-content">Loading...</div>'
    index_html += '\n            <div class="viewer-nav">'
    index_html += '\n              <a href="?">&lt;&lt; BACK TO DIRECTORY</a>'
    index_html += '\n              <a id="fv-raw" href="">[ DOWNLOAD / VIEW RAW ]</a>'
    index_html += '\n            </div>'
    index_html += '\n          </div>'
    
    index_html += '\n          <address>Apache/2.4.41 (Ubuntu) Server at rsrc.dontfeedmachines.com Port 80</address>'
    index_html += '\n' + HTML_FOOTER

    index_path = os.path.join(dir_path, 'index.html')
    with open(index_path, 'w', encoding='utf-8') as f_idx:
        f_idx.write(index_html)

def main():
    root_dir = '.'
    ignored_walk = {'.git', '.github', 'assets'} 
    
    for current_dir, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d not in ignored_walk and not d.startswith('.')]
        generate_index_for_directory(current_dir, root_dir)

if __name__ == "__main__":
    main()
